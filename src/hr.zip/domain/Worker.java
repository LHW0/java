package hr.domain;

import java.time.LocalDate;

public class Worker {
	private String name;
	private int ID;
	private LocalDate date;
	
	public Worker(String name, int ID, LocalDate date) {
		this.name = name;
		this.ID = ID++;
		this.date = date;
	}
	
	@Override
	public String toString() {
		return String.format("%5s %5s %5s", name, ID, date);
	}

}
