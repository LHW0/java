package hr.service;

import java.util.List;

import hr.domain.Worker;

public interface WorkerService {
	public void addWorker(Worker worker);
	public void removeWorker(Worker worker);
	List<Worker> getWorkers();
}
