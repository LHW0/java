package hrjava.dao;

import hrjava.domain.Worker;

public interface WorkerDao {
		public Worker selectWoker();
		public void insertWoker(Worker worker);
	}
