package hr.dao;

import java.util.List;

import hr.domain.Worker;

public class WorkerDaoImpl implements WorkerDao {
	private List<Worker> workers;
	
	public WorkerDaoImpl(List<Worker> workers) {
		this.workers = workers;
	}
	
	@Override
	public void insertWorker(Worker worker) {
		workers.add(worker);
	}
	
	@Override
	public void outWorker(Worker worker) {
		workers.remove(worker);
	}
	
	@Override
	public List<Worker> selectWorker() {
		return this.workers;
	}

}
