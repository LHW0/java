package hrjava.domain;

import java.time.LocalDate;

public class Worker {
	private int workerID;
	private String workerName;
	private LocalDate date;
	
	public Worker(String workerName) {
		this.workerName = workerName;
	}
	
	public Worker(int workerID) {
		this.workerID = workerID;
	}
	
	public Worker(LocalDate date) {
		this.date = date;
	}
	
	@Override
	public String toString() {
		return workerName;
	}
}