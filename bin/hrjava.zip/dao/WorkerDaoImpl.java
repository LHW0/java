package hrjava.dao;

import hrjava.domain.Worker;

public class WorkerDaoImpl implements WorkerDao {
	private Worker worker;
	
	@Override
	public Worker selectWoker() {
		return worker;
	}
	
	@Override
	public void insertWoker(Worker worker) {
		this.worker = worker;
		
	}



}
